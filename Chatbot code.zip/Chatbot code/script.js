
window.addEventListener('DOMContentLoaded', function() {
    var chatbotIcon = document.querySelector('#gethelpgpt');
    var chatWindow = document.querySelector('.chat-window');
    var chatWindowContent = document.querySelector('.chat-window-content');
    var explaintheques = document.querySelector('#explainTheQuestion');
    var giveHintButton = document.querySelector('#giveHintButton');
    var nowICanDoItButton = document.querySelector('#nowICanDoItButton');
    var detailedHintButton = document.querySelector('#detailedHintButton');
    var isGreeted = false; 
    let lastMessageElement = null;
   
    chatbotIcon.addEventListener('click', function() {
      toggleChatWindow();
      positionChatWindow();
    });

    function toggleChatWindow() {
      chatbotIcon.classList.toggle('show');
      chatWindow.classList.toggle('show');
      
      if (!isGreeted) {
        greetUser(); // Show greet message only if it hasn't been shown before
        isGreeted = true; // Update the flag to indicate that greet message has been shown
      }
    }
  

    function greetUser() {
      addMessageToChat('Hello! I am NeetGPT. How may I help you with this question?', false);
      addButtonsToChat(['Give me a hint','Explain the question']);
    }
    
    function positionChatWindow() {
      var buttonRect = chatbotIcon.getBoundingClientRect();
      var buttonRight = buttonRect.right;
      var windowWidth = chatWindow.offsetWidth;
      var windowHeight = chatWindow.offsetHeight;
      var pageWidth = window.innerWidth;
  
      var left = buttonRight + 10; // Adjust the value if needed
  
      // Adjust left position if it goes beyond the right edge of the page
      if (left + windowWidth > pageWidth) {
        left = pageWidth - windowWidth;
      }
  
      // Set the position of the chat window
      chatWindow.style.left = left + 'px';
      chatWindow.style.top = buttonRect.top + 'px';
      
    }
  
    function addWaitMessageToChat(){
      addMessageToChat('Wait for few seconds...',false);
    }
   
    function addMessageToChat(message, isUser) {
      var messageElement = document.createElement('div');
      messageElement.classList.add('message');
      messageElement.classList.add(isUser ? 'user-message' : 'chatbot-message');

       var contentWrapper = document.createElement('div');
      contentWrapper.classList.add('content-wrapper');

     if (!isUser) {
      var chatbotIcon = document.createElement('div');
      chatbotIcon.classList.add('chatbot-icn');
      contentWrapper.appendChild(chatbotIcon);
    }

     var messageContent = document.createElement('div');
     messageContent.textContent = message;
     if (isUser) {
      messageContent.classList.add('user-message-text');
    } else {
      messageContent.classList.add('chatbot-text');
    }
       contentWrapper.appendChild(messageContent);

       messageElement.appendChild(contentWrapper);
      chatWindowContent.appendChild(messageElement);
      chatWindowContent.scrollTop = chatWindowContent.scrollHeight;
      if (!isUser) {
        chatbotIcon.classList.add('show');
        lastMessageElement = messageElement;
      }
      // if (isUser) {
      //   setTimeout(function () {
      //     messageElement.classList.add('show'); // Add the 'show' class to reveal the user message smoothly
      //   }, 100); // Adjust the delay time as needed
      // } else {
      //   // For chatbot messages, show immediately
      //   messageElement.classList.add('show');
      // } 
      
    }
   
    function addButtonsToChat(buttons) {
      var buttonContainer = document.createElement('div');
      buttonContainer.classList.add('button-container');
      buttons.forEach(function(buttonText) {
        var button = document.createElement('button');
        button.textContent = buttonText;
        button.textContent = buttonText;
    button.id = buttonText.replace(/\s/g, ''); // Generate ID for the button
    button.addEventListener('click', function () {
      handleButtonResponse(buttonText);
    });
    buttonContainer.appendChild(button);   
  });

      var messageElement = document.createElement('div');
      messageElement.classList.add('message');
      messageElement.classList.add('user-message');
      messageElement.appendChild(buttonContainer);
      chatWindowContent.appendChild(messageElement);
      chatWindowContent.scrollTop = chatWindowContent.scrollHeight;
    }
    // function disableAllButtons() {
    //   const buttons = document.querySelectorAll('button');
    //   buttons.forEach((button) => {
    //     if (button.id !== 'gethelpgpt') {
    //       button.disabled = true;
    //     }
    //   });
    // }
   async function handleButtonResponse(buttonText) {
    // disableAllButtons();
      if (buttonText === 'Give me a hint') {
        var buttonContainer = document.querySelector('.button-container');
        // buttonContainer.classList.add('hidden'); 
        buttonContainer.parentNode.removeChild(buttonContainer);
        addMessageToChat(buttonText,true);
   
        await sendUserInput('Give me a hint')
        addButtonsToChat(['Now I can do it', 'Give me detailed hint and approach to solve the question']);
      } else if (buttonText === 'Now I can do it') {
        var buttonContainer = document.querySelector('.button-container');
        // buttonContainer.classList.add('hidden'); 
        buttonContainer.parentNode.removeChild(buttonContainer);
        addMessageToChat(buttonText,true);
       
        addMessageToChat('Happy to help!', false);
        hideButtons();
      } else if (buttonText === 'Give me detailed hint and approach to solve the question') {
        var buttonContainer = document.querySelector('.button-container');
        // buttonContainer.classList.add('hidden'); 
        buttonContainer.parentNode.removeChild(buttonContainer);
        addMessageToChat(buttonText,true);
        await sendUserInput('Give me detailed hint and approach to the question')
        addMessageToChat('Happy to help!',false);
        hideButtons();
      } else if(buttonText==='Explain the question'){
        var buttonContainer = document.querySelector('.button-container');
        // buttonContainer.classList.add('hidden'); 
        buttonContainer.parentNode.removeChild(buttonContainer);
        addMessageToChat(buttonText,true);
         await sendUserInput('Explain the question')
          addButtonsToChat(['Now I can do it','Give me a hint']);
      }
    
    }
   
  function hideButtons() {
      var buttonContainer = document.querySelector('.button-container');
      buttonContainer.classList.add('hidden');
      
    }

    giveHintButton.addEventListener('click', function() {
      handleButtonResponse('Give me a hint');
    });

    nowICanDoItButton.addEventListener('click', function() {
      handleButtonResponse('Now I can do it');
    });

    detailedHintButton.addEventListener('click', function() {
      handleButtonResponse('Give me detailed hint and approach to the question');
    });
    explaintheques.addEventListener('click',function(){
      handleButtonResponse('Explain the question');
    })
    
   
  async function sendUserInput(chatElement) {
    const apiUrl = 'https://79jplmfnz8.execute-api.ap-south-1.amazonaws.com/dev';
    const argument1 = 'A simple pendulum oscillating in air has a period of <span class="math-tex">\(\sqrt3\)</span> s. If it is completely immersed in non-viscous liquid, having density <span class="math-tex">\(\Big(\frac14\Big)^{th}\)</span> of the material of the bob, the new period will be:<br />1. <span class="math-tex">\(2\sqrt3\)</span> s<br />2. <span class="math-tex">\(\frac{2}{\sqrt3}\)</span> s<br />3. <span class="math-tex">\(2\)</span> s<br />4. <span class="math-tex">\(\frac{\sqrt 3}{2}\)</span> s'; // Replace with the actual value for argument 1
    const argument2 = '3'; // Replace with the actual value for argument 2
    const argument3 = chatElement; // Replace with the actual value for argument 3

    try {
      addWaitMessageToChat(); 
      const response = await axios.post(apiUrl, {
        question: argument1,
        option: argument2,
        usecase: argument3
      });
      const parser = new DOMParser();
      const parsedContent = parser.parseFromString(response.data.body, 'text/html').documentElement.textContent;
    const contentWrapper = lastMessageElement.querySelector('.content-wrapper');
    contentWrapper.innerHTML = ''; // Clear the existing content

    const chatbotIcon = document.createElement('div');
    chatbotIcon.classList.add('chatbot-icn');
    contentWrapper.appendChild(chatbotIcon);

    const messageContent = document.createElement('div');
    messageContent.textContent = parsedContent;
    messageContent.classList.add('chatbot-text');
    contentWrapper.appendChild(messageContent);
    chatWindowContent.scrollTop = chatWindowContent.scrollHeight;
    
    } catch (error) {
      addMessageToChat('Sorry, an error occurred. Please try again.');
    }   
}
  });